package com.example.expense_tracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpenseTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
